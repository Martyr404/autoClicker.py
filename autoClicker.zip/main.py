import pyautogui
import time
import tkinter as tk
from tkinter import simpledialog, messagebox
import os
import pyperclip
#运行本代码时候请关闭大写锁定，我也不知道为什么，等dalao指点

def openMelodyne():#打开melodyne
    # pos = pyautogui.locateCenterOnScreen("./icon/windowsBut2.png", confidence=0.9)#定位win11搜索功能并打开
    # pyautogui.moveTo(pos, duration=0.5)
    time.sleep(0.5)
    pyautogui.moveTo(849,1403,0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos=pyautogui.locateCenterOnScreen("./icon/winSearchBox.png", confidence=0.9)#搜索melodyne
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.write("Melodyne")
    time.sleep(0.5)
    pyautogui.press("enter")
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/MelodySearch.png", confidence=0.8)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(3.5)
    pos = pyautogui.locateCenterOnScreen("./icon/fullScreenBut.png", confidence=0.9)#点击全屏
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)

def show_custom_prompt():#对话框设置
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口

    # 设置自定义字体
    custom_font = ('Helvetica', 12)  # 例如使用 Helvetica 字体，大小为 12

    # 显示输入对话框
    user_input = simpledialog.askstring("来降的小破项目", "请输入目标WAV或MP3的路径：", parent=root)#, font=custom_font)，把root后括号去了
    mode_select = simpledialog.askstring("来降的小破项目", "请输入模式，女变男为1，男变女为2，女变孩为3，孩变女为4，男变孩为5，孩变男为6：", parent=root)
    mode_select=int(mode_select)

    if user_input:
        # 打印用户输入的路径
        print("用户输入的路径：", user_input)

        # 检查路径是否存在
        if os.path.exists(user_input):
            #messagebox.showinfo("输入结果", f"您输入的路径为：{user_input}") 备选代码
            return user_input,mode_select
        else:
            messagebox.showwarning("路径不存在", f"路径 '{user_input}' 不存在！")

    root.destroy()  # 关闭窗口

def openFile(filePath):
    pos = pyautogui.locateCenterOnScreen("./icon/fileBut.png", confidence=0.9)#打开文件
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/openBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/searchFileBox.png", confidence=0.9)
    time.sleep(0.5)

    #下面GUI后期优化
    pyperclip.copy(filePath)
    time.sleep(0.5)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.hotkey("ctrl","v")
    time.sleep(0.5)
    #上面GUI请修改

    pos = pyautogui.locateCenterOnScreen("./icon/openSBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)

def FtoM_changer():
    time.sleep(2.0)
    pyautogui.moveTo(1238,467,0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.keyDown("ctrl")
    time.sleep(0.1)
    pyautogui.press("a")
    time.sleep(0.05)
    pyautogui.keyUp("ctrl")
    time.sleep(0.5)
    searchRegion=(20,430,2525,917)
    pos = pyautogui.locateCenterOnScreen("./icon/waveSelect1.png", region=searchRegion,confidence=0.7)
    pyautogui.moveTo(pos, duration=1.0)
    pyautogui.dragRel(0,200,duration=1.0)#调低音调


    pos = pyautogui.locateCenterOnScreen("./icon/peakBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    pos = pyautogui.locateCenterOnScreen("./icon/peakSample.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    time.sleep(0.2)
    pyautogui.dragRel(0,100,duration=1.0)#调低共振峰
    time.sleep(0.2)
    pyautogui.mouseUp()
    time.sleep(0.2)

def MtoF_changer():
    time.sleep(5.0)
    pyautogui.moveTo(1238,467,0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.keyDown("ctrl")
    time.sleep(0.1)
    pyautogui.press("a")
    time.sleep(0.05)
    pyautogui.keyUp("ctrl")
    time.sleep(0.5)


    pos = pyautogui.locateCenterOnScreen("./icon/waveSelect2.png",confidence=0.9)
    pyautogui.moveTo(pos, duration=1.0)
    pyautogui.dragRel(0,-400,duration=1.0)#音调
    time.sleep(0.5)
    pyautogui.moveTo(1000, 700, 0.1)
    time.sleep(0.1)
    pyautogui.scroll(1200)
    time.sleep(0.5)



    pos = pyautogui.locateCenterOnScreen("./icon/peakBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    pos = pyautogui.locateCenterOnScreen("./icon/peakSample.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    time.sleep(0.2)
    pyautogui.dragRel(0,-100,duration=1.0)#调低共振峰
    time.sleep(0.2)
    pyautogui.mouseUp()
    time.sleep(0.2)

def FtoC_changer():
    time.sleep(2.0)
    pyautogui.moveTo(1238,467,0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.keyDown("ctrl")
    time.sleep(0.1)
    pyautogui.press("a")
    time.sleep(0.05)
    pyautogui.keyUp("ctrl")
    time.sleep(0.5)
    searchRegion=(20,430,2525,917)
    pos = pyautogui.locateCenterOnScreen("./icon/waveSelect3.png", region=searchRegion,confidence=0.8)
    pyautogui.moveTo(pos, duration=1.0)
    time.sleep(0.1)
    pyautogui.dragRel(0,100,duration=0.8)#调低音调


    pos = pyautogui.locateCenterOnScreen("./icon/peakBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    pos = pyautogui.locateCenterOnScreen("./icon/peakSample.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    time.sleep(0.2)
    pyautogui.dragRel(0,100,duration=1.0)#调低共振峰
    time.sleep(0.2)
    pyautogui.mouseUp()
    time.sleep(0.2)

def MtoC_changer():
    time.sleep(5.0)
    pyautogui.moveTo(1238,467,0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.keyDown("ctrl")
    time.sleep(0.1)
    pyautogui.press("a")
    time.sleep(0.05)
    pyautogui.keyUp("ctrl")
    time.sleep(0.5)
    searchRegion=(20,430,2525,917)
    pos = pyautogui.locateCenterOnScreen("./icon/waveSelect5.png", region=searchRegion,confidence=0.9)
    pyautogui.moveTo(pos, duration=1.0)
    pyautogui.dragRel(0,-200,duration=1.0)#提高音调
    time.sleep(0.5)
    pyautogui.scroll(800)
    time.sleep(0.5)


    pos = pyautogui.locateCenterOnScreen("./icon/peakBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    pos = pyautogui.locateCenterOnScreen("./icon/peakSample.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    time.sleep(0.2)
    pyautogui.dragRel(0,-100,duration=1.0)#调低共振峰
    time.sleep(0.2)
    pyautogui.mouseUp()
    time.sleep(0.2)

def CtoM_changer():
    time.sleep(2.0)
    pyautogui.moveTo(1238,467,0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.keyDown("ctrl")
    time.sleep(0.1)
    pyautogui.press("a")
    time.sleep(0.05)
    pyautogui.keyUp("ctrl")
    time.sleep(0.5)
    searchRegion=(20,430,2525,917)
    pos = pyautogui.locateCenterOnScreen("./icon/waveSelect4.png", region=searchRegion,confidence=0.7)
    pyautogui.moveTo(pos, duration=1.0)
    pyautogui.dragRel(0,200,duration=1.0)#调低音调


    pos = pyautogui.locateCenterOnScreen("./icon/peakBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    pos = pyautogui.locateCenterOnScreen("./icon/peakSample.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    time.sleep(0.2)
    pyautogui.dragRel(0,100,duration=1.0)#调低共振峰
    time.sleep(0.2)
    pyautogui.mouseUp()
    time.sleep(0.2)

def CtoF_changer():
    time.sleep(2.0)
    pyautogui.moveTo(1238,467,0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.keyDown("ctrl")
    time.sleep(0.1)
    pyautogui.press("a")
    time.sleep(0.05)
    pyautogui.keyUp("ctrl")
    time.sleep(0.5)
    searchRegion=(20,430,2525,917)
    pos = pyautogui.locateCenterOnScreen("./icon/waveSelect4.png", region=searchRegion,confidence=0.7)
    pyautogui.moveTo(pos, duration=1.0)
    pyautogui.dragRel(0,-200,duration=1.0)#音调


    pos = pyautogui.locateCenterOnScreen("./icon/peakBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    pos = pyautogui.locateCenterOnScreen("./icon/peakSample.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    time.sleep(0.2)
    pyautogui.dragRel(0,-100,duration=1.0)#共振峰
    time.sleep(0.2)
    pyautogui.mouseUp()
    time.sleep(0.2)

def saveFile():
    time.sleep(0.1)
    pos = pyautogui.locateCenterOnScreen("./icon/fileBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/exportBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/export2But.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    reg1=(1020,578,497,297)
    pos = pyautogui.locateCenterOnScreen("./icon/desktop.png",region=reg1, confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/autoClickerBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/outputBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pyautogui.press("enter")
    time.sleep(2.0)

def closeApp():
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/smallBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/closeBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)
    pos = pyautogui.locateCenterOnScreen("./icon/discardBut.png", confidence=0.9)
    pyautogui.moveTo(pos, duration=0.5)
    pyautogui.click()
    time.sleep(0.5)

def clearPkfFile(input_document,extension="pkf"):
    files= os.listdir(input_document)
    for file in files:
        if file.endswith(extension):
            filePath=os.path.join(input_document,file)
            os.remove(filePath)

filePath,mode=show_custom_prompt()
openMelodyne()
openFile(filePath)
if mode==1:
    FtoM_changer()
elif mode==2:
    MtoF_changer()
elif mode==3:
    FtoC_changer()#FtoC
elif mode==4:
    CtoF_changer()#CtoF
elif mode==5:
    MtoC_changer()#MtoC
elif mode==6:
    CtoM_changer()#CtoM
else:
    print("意外的mode输入mode:{}".format(mode))
saveFile()
closeApp()
clearPkfFile(r"C:\Users\28241\Desktop\autoClicker\output")
time.sleep(1.0)
print("执行完成")

#C:\Users\28241\Desktop\autoClicker\testAudio\10FtoC.mp3  完成
#C:\Users\28241\Desktop\autoClicker\testAudio\7FtoM.mp3   完成
#C:\Users\28241\Desktop\autoClicker\testAudio\7MtoF.mp3   完成
#C:\Users\28241\Desktop\autoClicker\testAudio\8MtoC.mp3   完成
#C:\Users\28241\Desktop\autoClicker\testAudio\CtoM.mp3    完成
#C:\Users\28241\Desktop\autoClicker\testAudio\CtoF.mp3    完成


