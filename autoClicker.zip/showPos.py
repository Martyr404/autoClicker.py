import time
import pyautogui
while 1:
    print(pyautogui.position())
    time.sleep(1.0)